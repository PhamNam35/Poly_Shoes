// ======= FE: suaSanPham.js =======

let sanPhamId;
let chiTietList = [];

document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  sanPhamId = urlParams.get("id");

  if (!sanPhamId) {
    alert("❌ Không có ID sản phẩm.");
    window.location.href = "admin.html";
    return;
  }

  loadThuocTinh();
  loadThuocTinhChiTiet(); // ✅ GỌI BỔ SUNG
  loadSanPham();
});

function loadThuocTinh() {
  fetch("http://localhost:8080/san-pham/thuoc-tinh")
    .then(res => res.json())
    .then(data => {
      fillSelect("thuong_hieu_id", data.thuongHieuList, "thuongHieuId", "tenThuongHieu");
      fillSelect("kieu_giay_id", data.kieuGiayList, "kieuGiayGiayId", "tenKieuGiayGiay");
      fillSelect("xuat_xu_id", data.xuatXuList, "xuatXuId", "tenDatNuocSanXuat");
      fillSelect("chat_lieu", data.chatLieuList.map(c => ({ chatLieu: c })), "chatLieu", "chatLieu");
    });
}

function loadThuocTinhChiTiet() {
  fetch("http://localhost:8080/san-pham/thuoc-tinh-chi-tiet")
    .then(res => res.json())
    .then(data => {
      fillSelect("kich_thuoc_id", data.kichThuocList, "kichThuocId", "size");
      fillSelect("mau_sac_id", data.mauSacList, "mauSacId", "tenMau");
    });
}

function fillSelect(id, list, valueKey, textKey) {
  const select = document.getElementById(id);
  if (!select || !list) return;
  select.innerHTML = "<option value=''>-- Chọn --</option>";
  list.forEach(item => {
    const opt = document.createElement("option");
    opt.value = item[valueKey];
    opt.textContent = item[textKey];
    select.appendChild(opt);
  });
}

function loadSanPham() {
  fetch(`http://localhost:8080/san-pham/${sanPhamId}`)
    .then(res => res.json())
    .then(sp => {
      document.getElementById("ten_sp").value = sp.tenSanPham;
      document.getElementById("mo_ta").value = sp.moTa;
      document.getElementById("ngay_nhap").value = sp.ngayNhap;
      document.getElementById("trang_thai").value = sp.trangThai;
      document.getElementById("thuong_hieu_id").value = sp.thuongHieu?.thuongHieuId || "";
      document.getElementById("kieu_giay_id").value = sp.kieuGiayGiay?.kieuGiayGiayId || "";
      document.getElementById("chat_lieu").value = sp.chatLieu || "";
      document.getElementById("xuat_xu_id").value = sp.xuatXu?.xuatXuId || "";

      chiTietList = sp.chiTietList?.map(ct => ({
        ...ct,
        soLuong: ct.soLuongTon
      })) || [];

      renderChiTietTable();
    });
}

function renderChiTietTable() {
  const tbody = document.querySelector("#bangChiTiet tbody");
  tbody.innerHTML = "";

  chiTietList.forEach((ct, index) => {
    const row = `
      <tr>
        <td>${ct.kichThuoc?.size || ""}</td>
        <td>${ct.mauSac?.tenMau || ""}</td>
        <td>${ct.soLuong || 0}</td>
        <td>${ct.giaBan?.toLocaleString() || 0} VNĐ</td>
        <td>${ct.trangThai ? "✅ Còn" : "❌ Hết"}</td>
        <td>${ct.ngayCapNhat || ""}</td>
        <td>
          <img src="${ct.duongDanAnh || '../img/default.jpg'}" width="60" onerror="this.src='../img/default.jpg'">
        </td>
      </tr>
    `;
    tbody.innerHTML += row;
  });
}

function capNhatSanPham() {
  const sp = {
    tenSanPham: document.getElementById("ten_sp").value.trim(),
    moTa: document.getElementById("mo_ta").value.trim(),
    ngayNhap: document.getElementById("ngay_nhap").value,
    trangThai: document.getElementById("trang_thai").value === "true",
    thuongHieuId: parseInt(document.getElementById("thuong_hieu_id").value),
    kieuGiayGiayId: parseInt(document.getElementById("kieu_giay_id").value),
    chatLieu: document.getElementById("chat_lieu").value,
    xuatXuId: parseInt(document.getElementById("xuat_xu_id").value)
  };

  if (!sp.tenSanPham || !sp.moTa || !sp.ngayNhap) {
    document.getElementById("thongbao").innerText = "❌ Không được để trống trường nào.";
    return;
  }

  fetch(`http://localhost:8080/san-pham/admin/${sanPhamId}`, {
    method: "PUT",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(sp)
  }).then(() => {
    alert("✅ Đã cập nhật sản phẩm chính.");
  });
}

function capNhatChiTiet() {
  for (let ct of chiTietList) {
    if (ct.soLuong < 0 || ct.giaBan < 0) {
      alert("❌ Số lượng và giá bán không được âm.");
      return;
    }
  }

  const listToSend = chiTietList.map(ct => ({
    ...ct,
    soLuongTon: ct.soLuong
  }));

  fetch(`http://localhost:8080/chi-tiet-san-pham/admin/${sanPhamId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(listToSend)
  })
    .then(() => {
      alert("✅ Đã cập nhật chi tiết sản phẩm.");
    });
}
