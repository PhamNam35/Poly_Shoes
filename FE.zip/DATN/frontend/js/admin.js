let tatCaSanPham = [];
const spMoiTrang = 10;

// Ẩn/hiện các tab
function showTab(id) {
  document.querySelectorAll(".tab-content").forEach(tab => tab.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");

  if (id === "quan-ly-sp") {
    loadThuocTinh();
    loadSanPham();
  }
}

// ========== Load các combo box ==========
function loadThuocTinh() {
  fetch("http://localhost:8080/san-pham/thuoc-tinh")
    .then(res => res.json())
    .then(data => {
      fillSelect("thuong_hieu_id", data.thuongHieuList, "thuongHieuId", "tenThuongHieu");
      fillSelect("kieu_giay_id", data.kieuGiayList, "kieuGiayGiayId", "tenKieuGiayGiay");
      fillSelect("xuat_xu_id", data.xuatXuList, "xuatXuId", "tenDatNuocSanXuat");
      fillSelect("chat_lieu", data.chatLieuList, null, null); // vì value = text


      fillSelect("locThuongHieu", data.thuongHieuList, "tenThuongHieu", "tenThuongHieu", true);
      fillSelect("locKieuGiay", data.kieuGiayList, "tenKieuGiayGiay", "tenKieuGiayGiay", true);
    });
}

function fillSelect(id, list, valueKey, textKey, addEmpty) {
  const select = document.getElementById(id);
  if (!list || !Array.isArray(list)) return;
  select.innerHTML = addEmpty ? `<option value="">-- Tất cả --</option>` : "";

  list.forEach(item => {
    const opt = document.createElement("option");
    opt.value = valueKey ? item[valueKey] : item;
    opt.textContent = textKey ? item[textKey] : item;
    select.appendChild(opt);
  });
}


// -----Validate---------
function validateSanPham(sp) {
  const tb = document.getElementById("thongbao");
  const hasSpecial = /[^a-zA-Z0-9\s\u00C0-\u1EF9]/g;
  const hasSpace = /^\s|\s$/;

  if (!sp.tenSanPham || !sp.moTa || !sp.ngayNhap || !sp.kieuGiayGiayId || !sp.chatLieu || !sp.xuatXuId) {
    tb.innerText = "❌ Không được để trống trường nào.";
    return false;
  }

  if (hasSpace.test(sp.tenSanPham) || hasSpace.test(sp.moTa)) {
    tb.innerText = "❌ Không được có khoảng trắng đầu hoặc cuối.";
    return false;
  }

  if (hasSpecial.test(sp.tenSanPham)) {
    tb.innerText = "❌ Không được chứa ký tự đặc biệt.";
    return false;
  }

  const trung = tatCaSanPham.find(s => s.tenSanPham.toLowerCase() === sp.tenSanPham.toLowerCase());
  if (trung) {
    tb.innerText = "❌ Tên sản phẩm đã tồn tại.";
    return false;
  }

  tb.innerText = "";
  return true;
}

// ========== Lấy form ==========
function laySanPhamTuForm() {
  return {
    tenSanPham: document.getElementById("ten_sp").value.trim(),
    moTa: document.getElementById("mo_ta").value.trim(),
    ngayNhap: document.getElementById("ngay_nhap").value,
    trangThai: document.getElementById("trang_thai").value === "true",
    thuongHieuId: parseInt(document.getElementById("thuong_hieu_id").value),
    kieuGiayGiayId: parseInt(document.getElementById("kieu_giay_id").value),
    xuatXuId: parseInt(document.getElementById("xuat_xu_id").value),
    chatLieu: document.getElementById("chat_lieu").value.trim() || "Da"
  };
}

// ========== CRUD ==========
function themSanPham() {
  const sp = laySanPhamTuForm();
  const thongbao = document.getElementById("thongbao");

  if (!validateSanPham(sp)) return;

  if (!confirm("❓ Bạn có chắc muốn thêm sản phẩm mới không?")) {
    thongbao.innerText = "⛔ Đã huỷ thêm sản phẩm.";
    return;
  }

  fetch("http://localhost:8080/san-pham/admin", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(sp)
  }).then(() => {
    alert("✅ Thêm sản phẩm thành công.");
    loadSanPham();
  });
}

function suaSanPham(id) {
  window.location.href = `suaSanPham.html?id=${id}`;
}

function xoaSanPham(id) {
  if (!confirm("❓ Xác nhận xoá sản phẩm này?")) return;

  fetch(`http://localhost:8080/san-pham/admin/${id}`, {
    method: "DELETE"
  })
    .then(res => {
      if (!res.ok) throw new Error("❌ Xoá thất bại.");
      return res.text();
    })
    .then(() => {
      alert("✅ Đã xoá sản phẩm.");
      loadSanPham(); // Tải lại danh sách để render mới
    })
    .catch(err => {
      alert(err.message);
    });
}


// ========== Load danh sách ==========
function loadSanPham() {
  fetch("http://localhost:8080/san-pham/admin")
    .then(res => res.json())
    .then(data => {
      tatCaSanPham = data;
      renderSanPham(tatCaSanPham, 1);
    });
}


function renderSanPham(list, page) {
  const tbody = document.querySelector("#bangSanPham tbody");
  tbody.innerHTML = "";

  const start = (page - 1) * spMoiTrang;
  const end = start + spMoiTrang;
  const current = list.slice(start, end);

  current.forEach((sp, index) => {
    const stt = start + index + 1; // 👉 số thứ tự từ 1

    const row = `
      <tr>
        <td>${stt}</td>
        <td>${sp.tenSanPham}</td>
        <td>${sp.soLuongTon || 0}</td>
        <td>${sp.trangThai ? "✅" : "❌"}</td>
        <td>
          <button onclick="themChiTiet(${sp.sanPhamId})">✏️Sửa </button>
          <button onclick="suaSanPham(${sp.sanPhamId})">➕Chi tiết</button>
          <button onclick="xoaSanPham(${sp.sanPhamId})">🗑️ Xoá</button>
        </td>
      </tr>
    `;
    tbody.innerHTML += row;
  });

  renderPhanTrang(list.length);
}



function renderPhanTrang(tong) {
  const div = document.getElementById("phanTrang");
  div.innerHTML = "";
  const soTrang = Math.ceil(tong / spMoiTrang);
  for (let i = 1; i <= soTrang; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    btn.onclick = () => renderSanPham(tatCaSanPham, i);
    div.appendChild(btn);
  }
}

// ========== Tìm kiếm ==========
function timKiemSanPham() {
  const ten = document.getElementById("searchTen").value.toLowerCase();
  const thuongHieu = document.getElementById("locThuongHieu").value;
  const kieuGiay = document.getElementById("locKieuGiay").value;

  const loc = tatCaSanPham.filter(sp => {
    return (
      (!ten || sp.tenSanPham.toLowerCase().includes(ten)) &&
      (!thuongHieu || sp.thuongHieu?.tenThuongHieu === thuongHieu) &&
      (!kieuGiay || sp.kieuGiayGiay?.tenKieuGiayGiay === kieuGiay)
    );
  });

  renderSanPham(loc, 1);
}

// ========== Chuyển tới thêm chi tiết ==========
function themChiTiet(spId) {
  window.location.href = `themChiTiet.html?id=${spId}`;
}
