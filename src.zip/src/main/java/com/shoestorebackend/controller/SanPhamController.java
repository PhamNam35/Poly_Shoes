package com.shoestorebackend.controller;

import com.shoestorebackend.dto.CreateChiTietRequest;
import com.shoestorebackend.dto.CreateSanPhamRequest;
import com.shoestorebackend.dto.SanPhamDTO;
import com.shoestorebackend.entity.ChiTietSanPham;
import com.shoestorebackend.entity.KichThuoc;
import com.shoestorebackend.entity.MauSac;
import com.shoestorebackend.entity.SanPham;
import com.shoestorebackend.repository.*;
import com.shoestorebackend.service.SanPhamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/san-pham")
@CrossOrigin(origins = "*")
public class SanPhamController {

    @Autowired
    private SanPhamService sanPhamService;

    @Autowired
    private ThuongHieuRepository thuongHieuRepository;

    @Autowired
    private KieuGiayRepository kieuGiayRepository;

    @Autowired
    private XuatXuRepository xuatXuRepository;

    @Autowired
    private SanPhamRepository sanPhamRepository;
    @Autowired
    private KichThuocRepository kichThuocRepository;
    @Autowired
    private MauSacRepository mauSacRepository;
    @Autowired
    private ChiTietSanPhamRepository chiTietSanPhamRepository;


    @GetMapping
    public ResponseEntity<List<SanPhamDTO>> getAllSanPham() {
        return ResponseEntity.ok(sanPhamService.getAllSanPhamActive());
    }


    @GetMapping("/admin")
    public ResponseEntity<List<SanPhamDTO>> getAllForAdmin() {
        return ResponseEntity.ok(sanPhamService.getAllSanPhamDTO());
    }




    @PostMapping("/admin")
    public ResponseEntity<SanPham> create(@RequestBody CreateSanPhamRequest request) {
        return ResponseEntity.ok(sanPhamService.createSanPham(request));
    }

    @PutMapping("/admin/{id}")
    public ResponseEntity<SanPham> update(@PathVariable Integer id, @RequestBody CreateSanPhamRequest request) {
        return ResponseEntity.ok(sanPhamService.updateSanPham(id, request));
    }

    @DeleteMapping("/admin/{id}")
    public ResponseEntity<Void> deleteSanPham(@PathVariable Integer id) {
        sanPhamService.deleteSanPham(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SanPhamDTO> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(sanPhamService.getSanPhamById(id));
    }
    @GetMapping("/thuoc-tinh")
    public ResponseEntity<?> getThuocTinh() {
        Map<String, Object> map = new HashMap<>();
        map.put("thuongHieuList", thuongHieuRepository.findAll());
        map.put("kieuGiayList", kieuGiayRepository.findAll());
        map.put("xuatXuList", xuatXuRepository.findAll());
        map.put("chatLieuList", Arrays.asList("Da", "Vải", "Nhựa", "Cao su"));
        return ResponseEntity.ok(map);
    }
    @PostMapping("/chi-tiet-san-pham")
    public ResponseEntity<?> addChiTiet(@RequestBody CreateChiTietRequest request) {
        Optional<SanPham> sp = sanPhamRepository.findById(request.getSanPhamId());
        Optional<KichThuoc> kt = kichThuocRepository.findById(request.getKichThuocId());
        Optional<MauSac> ms = mauSacRepository.findById(request.getMauSacId());

        if (sp.isEmpty() || kt.isEmpty() || ms.isEmpty()) {
            return ResponseEntity.badRequest().body("Thiếu dữ liệu");
        }

        ChiTietSanPham ct = new ChiTietSanPham();
        ct.setSanPham(sp.get());
        ct.setKichThuoc(kt.get());
        ct.setMauSac(ms.get());
        ct.setSoLuongTon(request.getSoLuong());
        ct.setGiaBan(request.getGiaBan());
        ct.setTrangThai(request.getTrangThai());
        ct.setNgayCapNhat(LocalDate.now());
        ct.setDuongDanAnh(request.getDuongDanAnh());

        chiTietSanPhamRepository.save(ct);

        return ResponseEntity.ok("Đã thêm chi tiết sản phẩm");
    }
    @GetMapping("/thuoc-tinh-chi-tiet")
    public ResponseEntity<?> getChiTietThuocTinh() {
        Map<String, Object> map = new HashMap<>();
        map.put("mauSacList", mauSacRepository.findAll());
        map.put("kichThuocList", kichThuocRepository.findAll());
        return ResponseEntity.ok(map);
    }



}


