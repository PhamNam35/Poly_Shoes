package com.shoestorebackend.dto;

import com.shoestorebackend.entity.KichThuoc;
import com.shoestorebackend.entity.MauSac;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ChiTietSanPhamDTO {
    private Integer chiTietSpId;
    private KichThuoc kichThuoc;   // ✅ giữ nguyên object nếu muốn load toàn bộ thông tin
    private MauSac mauSac;         // ✅ như trên
    private Integer soLuongTon;
    private boolean trangThai;
    private LocalDate ngayCapNhat;
    private BigDecimal giaBan;
    private String duongDanAnh;
}
