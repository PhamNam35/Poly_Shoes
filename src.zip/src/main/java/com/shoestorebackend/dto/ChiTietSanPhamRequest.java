package com.shoestorebackend.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ChiTietSanPhamRequest {
    private Integer sanPhamId;
    private Integer kichThuocId;
    private Integer mauSacId;
    private Integer soLuong; // lấy từ FE
    private BigDecimal giaBan;
    private Boolean trangThai;
}
