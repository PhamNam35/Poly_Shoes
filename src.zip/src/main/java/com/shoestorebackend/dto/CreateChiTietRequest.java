package com.shoestorebackend.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreateChiTietRequest {
    private Integer sanPhamId;
    private Integer kichThuocId;
    private Integer mauSacId;

    private Integer soLuong; // phải đúng tên và kiểu như thế này
    private BigDecimal giaBan;
    private Boolean trangThai;
    private String duongDanAnh;
}
