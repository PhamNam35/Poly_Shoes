package com.shoestorebackend.dto;

import com.shoestorebackend.entity.KieuGiayGiay;
import com.shoestorebackend.entity.ThuongHieu;
import com.shoestorebackend.entity.XuatXu;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class SanPhamDTO {
    private Integer sanPhamId;
    private String tenSanPham;
    private String moTa;
    private String chatLieu;
    private LocalDate ngayNhap;
    private boolean trangThai;
    private Integer soLuongTon;
    private BigDecimal giaBan;
    private String duongDanAnh;

    private ThuongHieu thuongHieu;
    private KieuGiayGiay kieuGiayGiay;
    private XuatXu xuatXu;

    private List<ChiTietSanPhamDTO> chiTietList;

}
