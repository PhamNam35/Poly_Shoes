package com.shoestorebackend.service.impl;

import com.shoestorebackend.dto.ChiTietSanPhamDTO;
import com.shoestorebackend.dto.CreateSanPhamRequest;
import com.shoestorebackend.dto.SanPhamDTO;
import com.shoestorebackend.entity.ChiTietSanPham;
import com.shoestorebackend.entity.HinhAnhSanPham;
import com.shoestorebackend.entity.SanPham;
import com.shoestorebackend.repository.*;
import com.shoestorebackend.service.SanPhamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SanPhamServiceImpl implements SanPhamService {

    private final ChiTietSanPhamRepository chiTietSanPhamRepository;

    @Autowired
    public SanPhamServiceImpl(SanPhamRepository sanPhamRepository,
                              ChiTietSanPhamRepository chiTietSanPhamRepository) {
        this.sanPhamRepository = sanPhamRepository;
        this.chiTietSanPhamRepository = chiTietSanPhamRepository;
    }




    @Autowired
    private SanPhamRepository sanPhamRepository;

    @Autowired
    private ThuongHieuRepository thuongHieuRepository;

    @Autowired
    private KieuGiayRepository kieuGiayRepository;

    @Autowired
    private XuatXuRepository xuatXuRepository;

    @Override
    public List<SanPhamDTO> getAllSanPhamActive() {
        List<SanPham> danhSach = sanPhamRepository.findByTrangThaiTrue();

        return danhSach.stream().map(sp -> {
            SanPhamDTO dto = new SanPhamDTO();
            dto.setSanPhamId(sp.getSanPhamId());
            dto.setTenSanPham(sp.getTenSanPham());
            dto.setMoTa(sp.getMoTa());
            dto.setChatLieu(sp.getChatLieu());

            // Nếu có chi tiết sản phẩm → lấy thông tin từ bản ghi đầu tiên
            if (!sp.getChiTietSanPhams().isEmpty()) {
                ChiTietSanPham ct = sp.getChiTietSanPhams().get(0);
                dto.setGiaBan(ct.getGiaBan());
                dto.setSoLuongTon(ct.getSoLuongTon()
                );
                dto.setTrangThai(ct.isTrangThai());

                Optional<HinhAnhSanPham> anhChinh = ct.getHinhAnhSanPhams()
                        .stream()
                        .filter(HinhAnhSanPham::getAnhChinh)
                        .findFirst();

                anhChinh.ifPresent(ha -> dto.setDuongDanAnh(ha.getDuongDanAnh()));
            }

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public List<SanPhamDTO> getAllSanPhamDTO() {
        List<SanPham> danhSach = sanPhamRepository.findAll();

        return danhSach.stream().map(sp -> {
            SanPhamDTO dto = new SanPhamDTO();
            dto.setSanPhamId(sp.getSanPhamId());
            dto.setTenSanPham(sp.getTenSanPham());
            dto.setMoTa(sp.getMoTa());
            dto.setNgayNhap(sp.getNgayNhap());
            dto.setChatLieu(sp.getChatLieu());

            // map thông tin chi tiết sản phẩm
            if (!sp.getChiTietSanPhams().isEmpty()) {
                ChiTietSanPham ct = sp.getChiTietSanPhams().get(0);
                dto.setGiaBan(ct.getGiaBan());
                dto.setSoLuongTon(ct.getSoLuongTon());
                dto.setTrangThai(ct.isTrangThai());

                Optional<HinhAnhSanPham> anhChinh = ct.getHinhAnhSanPhams()
                        .stream()
                        .filter(HinhAnhSanPham::getAnhChinh)
                        .findFirst();

                anhChinh.ifPresent(ha -> dto.setDuongDanAnh(ha.getDuongDanAnh()));
            }

            if (sp.getThuongHieu() != null) dto.setThuongHieu(sp.getThuongHieu());
            if (sp.getKieuGiayGiay() != null) dto.setKieuGiayGiay(sp.getKieuGiayGiay());
            if (sp.getXuatXu() != null) dto.setXuatXu(sp.getXuatXu());

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public SanPham createSanPham(CreateSanPhamRequest request) {
        SanPham sp = new SanPham();
        sp.setTenSanPham(request.getTenSanPham());
        sp.setTrangThai(request.getTrangThai());
        sp.setChatLieu(request.getChatLieu());
        sp.setMoTa(request.getMoTa());
        sp.setNgayNhap(request.getNgayNhap());
        sp.setThuongHieu(thuongHieuRepository.findById(request.getThuongHieuId()).orElse(null));
        sp.setKieuGiayGiay(kieuGiayRepository.findById(request.getKieuGiayGiayId()).orElse(null));
        sp.setXuatXu(xuatXuRepository.findById(request.getXuatXuId()).orElse(null));
        return sanPhamRepository.save(sp);
    }

    @Override
    public SanPham updateSanPham(Integer id, CreateSanPhamRequest request) {
        SanPham sp = sanPhamRepository.findById(id).orElseThrow();
        sp.setTenSanPham(request.getTenSanPham());
        sp.setTrangThai(request.getTrangThai());
        sp.setChatLieu(request.getChatLieu());
        sp.setMoTa(request.getMoTa());
        sp.setNgayNhap(request.getNgayNhap());
        sp.setThuongHieu(thuongHieuRepository.findById(request.getThuongHieuId()).orElse(null));
        sp.setKieuGiayGiay(kieuGiayRepository.findById(request.getKieuGiayGiayId()).orElse(null));
        sp.setXuatXu(xuatXuRepository.findById(request.getXuatXuId()).orElse(null));
        return sanPhamRepository.save(sp);
    }

    @Override
    public SanPhamDTO getSanPhamById(Integer id) {
        SanPham sp = sanPhamRepository.findById(id).orElseThrow();
        SanPhamDTO dto = new SanPhamDTO();

        dto.setSanPhamId(sp.getSanPhamId());
        dto.setTenSanPham(sp.getTenSanPham());
        dto.setMoTa(sp.getMoTa());
        dto.setChatLieu(sp.getChatLieu());
        dto.setNgayNhap(sp.getNgayNhap());
        dto.setThuongHieu(sp.getThuongHieu());
        dto.setKieuGiayGiay(sp.getKieuGiayGiay());
        dto.setXuatXu(sp.getXuatXu());

        // ✅ Map toàn bộ danh sách chi tiết sản phẩm
        List<ChiTietSanPham> chiTietSanPhams = sp.getChiTietSanPhams();
        if (chiTietSanPhams != null && !chiTietSanPhams.isEmpty()) {
            dto.setChiTietList(
                    chiTietSanPhams.stream().map(ct -> {
                        ChiTietSanPhamDTO ctDTO = new ChiTietSanPhamDTO();
                        ctDTO.setGiaBan(ct.getGiaBan());
                        ctDTO.setSoLuongTon(ct.getSoLuongTon()); // FE dùng key "soLuong"
                        ctDTO.setTrangThai(ct.isTrangThai());
                        ctDTO.setNgayCapNhat(ct.getNgayCapNhat());
                        ctDTO.setKichThuoc(ct.getKichThuoc());
                        ctDTO.setMauSac(ct.getMauSac());

                        // ✅ Ảnh (ưu tiên duongDanAnh trong ct nếu có)
                        if (ct.getDuongDanAnh() != null) {
                            ctDTO.setDuongDanAnh(ct.getDuongDanAnh());
                        } else {
                            Optional<HinhAnhSanPham> anhChinh = ct.getHinhAnhSanPhams()
                                    .stream()
                                    .filter(HinhAnhSanPham::getAnhChinh)
                                    .findFirst();
                            anhChinh.ifPresent(ha -> ctDTO.setDuongDanAnh(ha.getDuongDanAnh()));
                        }

                        return ctDTO;
                    }).collect(Collectors.toList())
            );
        }

        return dto;
    }


    @Override
    public void deleteSanPham(Integer id) {
        SanPham sanPham = sanPhamRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm"));

        // 1. Xoá toàn bộ Chi tiết sản phẩm
        chiTietSanPhamRepository.deleteBySanPhamId(id);

        // 2. Nếu có các liên kết khác như giỏ hàng, đơn hàng... thì xoá/huỷ liên kết ở đây

        // 3. Xoá sản phẩm chính
        sanPhamRepository.deleteById(id);
    }



}
