package com.shoestorebackend.service.impl;

import com.shoestorebackend.dto.ChiTietSanPhamDTO;
import com.shoestorebackend.dto.ChiTietSanPhamRequest;
import com.shoestorebackend.entity.*;
import com.shoestorebackend.repository.*;
import com.shoestorebackend.service.ChiTietSanPhamService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChiTietSanPhamServiceImpl implements ChiTietSanPhamService {

    @Autowired
    private ChiTietSanPhamRepository chiTietSanPhamRepository;

    @Autowired
    private SanPhamRepository sanPhamRepository;

    @Autowired
    private KichThuocRepository kichThuocRepository;

    @Autowired
    private MauSacRepository mauSacRepository;

    @Override
    public List<ChiTietSanPhamDTO> getBySanPhamId(Integer sanPhamId) {
        List<ChiTietSanPham> list = chiTietSanPhamRepository.findBySanPhamSanPhamId(sanPhamId);
        List<ChiTietSanPhamDTO> dtos = new ArrayList<>();
        for (ChiTietSanPham ct : list) {
            ChiTietSanPhamDTO dto = new ChiTietSanPhamDTO();
            dto.setChiTietSpId(ct.getChiTietSpId());
            dto.setSoLuongTon(ct.getSoLuongTon()); // map đúng field gốc
            dto.setGiaBan(ct.getGiaBan());
            dto.setTrangThai(ct.isTrangThai());
            dto.setNgayCapNhat(ct.getNgayCapNhat());
            dto.setKichThuoc(ct.getKichThuoc());

            dto.setMauSac(ct.getMauSac());
            dto.setDuongDanAnh(ct.getHinhAnhSanPham() != null ? ct.getHinhAnhSanPham().getDuongDanAnh() : null);
            dtos.add(dto);
        }
        return dtos;
    }

    @Override
    @Transactional
    public void updateChiTietSanPhamList(Integer sanPhamId, List<ChiTietSanPhamRequest> list) {
        SanPham sp = sanPhamRepository.findById(sanPhamId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm"));

        // Xoá toàn bộ chi tiết cũ trước khi thêm mới (nếu cần)
        chiTietSanPhamRepository.deleteBySanPham_SanPhamId(sanPhamId);

        for (ChiTietSanPhamRequest req : list) {
            ChiTietSanPham ct = new ChiTietSanPham();
            ct.setSanPham(sp);
            ct.setKichThuoc(kichThuocRepository.findById(req.getKichThuocId()).orElse(null));
            ct.setMauSac(mauSacRepository.findById(req.getMauSacId()).orElse(null));
            ct.setSoLuongTon(req.getSoLuong()); // set vào entity đúng tên
            ct.setGiaBan(req.getGiaBan());
            ct.setTrangThai(req.getTrangThai());
            ct.setNgayCapNhat(java.time.LocalDate.now());

            chiTietSanPhamRepository.save(ct);
        }
    }
}
