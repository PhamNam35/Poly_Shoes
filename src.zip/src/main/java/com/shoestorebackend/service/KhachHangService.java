package com.shoestorebackend.service;

import com.shoestorebackend.entity.KhachHang;

public interface KhachHangService {
    KhachHang login(String username, String password);
}

