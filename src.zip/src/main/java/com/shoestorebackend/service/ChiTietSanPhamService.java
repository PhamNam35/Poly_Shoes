package com.shoestorebackend.service;

import com.shoestorebackend.dto.ChiTietSanPhamRequest;
import com.shoestorebackend.dto.ChiTietSanPhamDTO;

import java.util.List;

public interface ChiTietSanPhamService {
    List<ChiTietSanPhamDTO> getBySanPhamId(Integer sanPhamId);
    void updateChiTietSanPhamList(Integer sanPhamId, List<ChiTietSanPhamRequest> list);
}
